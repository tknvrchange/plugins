jQuery(document).ready(function ($) {
    $('#add-slider-image').on('click', function (e) {
        e.preventDefault();

        const frame = wp.media({
            title: 'Select Images',
            multiple: true,
            library: { type: 'image' },
            button: { text: 'Add Images' }
        });

        frame.on('select', function () {
            const selection = frame.state().get('selection');

            selection.each(function (attachment) {
                attachment = attachment.toJSON();

                $.post(csSliderAjax.ajax_url, {
                    action: 'cs_add_slider_image',
                    nonce: csSliderAjax.nonce,
                    image_url: attachment.url
                });
            });

            // Wait a moment then reload to show new images
            setTimeout(() => location.reload(), 1000);
        });

        frame.open();
    });

    $('.remove-image').on('click', function () {
        const li = $(this).closest('li');
        const id = li.data('id');

        $.post(csSliderAjax.ajax_url, {
            action: 'cs_remove_slider_image',
            nonce: csSliderAjax.nonce,
            image_id: id
        }, function () {
            li.fadeOut(300, function () {
                $(this).remove();
            });
        });
    });

    $('#slider-image-list').sortable({
        update: function () {
            const order = [];
            $('#slider-image-list li').each(function () {
                order.push($(this).data('id'));
            });

            $.post(csSliderAjax.ajax_url, {
                action: 'cs_update_slider_order',
                nonce: csSliderAjax.nonce,
                order: order
            });
        }
    });
});
