<?php
/*
Plugin Name: CS Slider
Description: Admin slider with image upload, reordering, and sitemap.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

// Activation Hook - Create Table
register_activation_hook(__FILE__, 'cs_create_slider_table');

function cs_create_slider_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'cs_slider';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            image_url TEXT NOT NULL,
            position INT DEFAULT 0,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// Admin Menu
add_action('admin_menu', function() {
    add_menu_page('Slider', 'Slider', 'manage_options', 'cs-slider', 'cs_slider_admin_page', 'dashicons-images-alt2', 20);
});

// Admin Page
function cs_slider_admin_page() {
    ?>
    <div class="wrap">
        <h1>Slider Images</h1>
        <button id="add-slider-image" class="button button-primary">Add Image</button>
        <ul id="slider-image-list" class="sortable-images">
            <?php
            global $wpdb;
            $table = $wpdb->prefix . 'cs_slider';
            $images = $wpdb->get_results("SELECT * FROM $table ORDER BY position ASC");
            foreach ($images as $img) {
                echo '<li data-id="' . esc_attr($img->id) . '">';
                echo '<img src="' . esc_url($img->image_url) . '" style="max-width:100px; margin-right:10px;">';
                echo '<button class="remove-image button">Remove</button>';
                echo '</li>';
            }
            ?>
        </ul>
    </div>
    <style>
        #slider-image-list { list-style: none; padding: 0; margin-top: 20px; }
        #slider-image-list li { margin: 10px 0; display: flex; align-items: center; }
    </style>
    <?php
}

// Enqueue JS
add_action('admin_enqueue_scripts', function($hook) {
    if ($hook !== 'toplevel_page_cs-slider') return;

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script('cs-slider-js', plugin_dir_url(__FILE__) . 'slider-admin.js', ['jquery'], null, true);
    wp_localize_script('cs-slider-js', 'csSliderAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('cs_slider_nonce')
    ]);
});

// AJAX Handlers
add_action('wp_ajax_cs_add_slider_image', function() {
    check_ajax_referer('cs_slider_nonce', 'nonce');
    global $wpdb;
    $url = esc_url_raw($_POST['image_url']);
    $table = $wpdb->prefix . 'cs_slider';
    $max_position = $wpdb->get_var("SELECT MAX(position) FROM $table") + 1;
    $wpdb->insert($table, ['image_url' => $url, 'position' => $max_position]);
    wp_send_json_success();
});

add_action('wp_ajax_cs_remove_slider_image', function() {
    check_ajax_referer('cs_slider_nonce', 'nonce');
    global $wpdb;
    $id = intval($_POST['image_id']);
    $wpdb->delete($wpdb->prefix . 'cs_slider', ['id' => $id]);
    wp_send_json_success();
});

add_action('wp_ajax_cs_update_slider_order', function() {
    check_ajax_referer('cs_slider_nonce', 'nonce');
    global $wpdb;
    foreach ($_POST['order'] as $position => $id) {
        $wpdb->update($wpdb->prefix . 'cs_slider', ['position' => $position], ['id' => intval($id)]);
    }
    wp_send_json_success();
});

// Enqueue Slick Slider for frontend
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('slick-css', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
    wp_enqueue_style('slick-theme-css', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');
    wp_enqueue_script('slick-js', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', ['jquery'], null, true);
});

// Shortcode to Display Slider Images
add_shortcode('cs_slider', 'cs_slider_shortcode');

function cs_slider_shortcode() {
    global $wpdb;
    $table = $wpdb->prefix . 'cs_slider';
    $images = $wpdb->get_results("SELECT * FROM $table ORDER BY position ASC");

    if (!$images) return '<p>No slider images found.</p>';

    ob_start();
    ?>
    <div class="cs-slider slick-slider">
        <?php foreach ($images as $img): ?>
            <div class="cs-slide">
                <img src="<?php echo esc_url($img->image_url); ?>" alt="" />
            </div>
        <?php endforeach; ?>
    </div>

    <style>
        .cs-slider {
            max-width: 800px;
            margin: 0 auto;
        }
        .cs-slide img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }
    </style>

    <script>
    window.addEventListener('load', function () {
        jQuery('.cs-slider').slick({
            dots: true,
            arrows: true,
            infinite: true,
            speed: 500, // slightly reduced transition speed for snappier feel
            fade: true,
            cssEase: 'linear',
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 3000
        });
    });
    </script>
    <?php
    return ob_get_clean();
}